
var trex ,trex_running;
function preload(){
  

}

function setup(){
  createCanvas(600,200)

  //create a trex sprite
  trex=createSprite(50,100,20,50);
}

function draw(){
  background("white")
  drawSprites();

}
